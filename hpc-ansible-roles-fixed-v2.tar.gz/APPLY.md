# Applying v2 on the master (/opt/hpc-ansible)

    # 0. Back up the project
    tar czf /root/hpc-ansible-backup-$(date +%F-%H%M).tgz -C /opt hpc-ansible

    # 1. Unpack and copy in
    mkdir -p /root/v2 && tar xzf /root/hpc-ansible-roles-fixed-v2.tar.gz -C /root/v2
    cd /opt/hpc-ansible
    cp -a /root/v2/cobbler_provisioning /root/v2/compute_packages roles/
    cp /root/v2/project/master.yml master.yml
    cp /root/v2/project/inventory/kvm/group_vars/master/provisioning.yml inventory/kvm/group_vars/master/
    mkdir -p lab && cp -a /root/v2/lab/. lab/

    # 2. Vault password file (for unattended hpc-node-configure). Type it, press Enter.
    ( umask 077; read -rsp 'Vault password: ' P; echo; printf '%s\n' "$P" > /root/.vault_pass )

    # 3. (KVM lab with VirtualBMC) add vault_ipmi_password: <VBMC_PASS> to the vault
    ansible-vault edit inventory/kvm/group_vars/master/vault.yml --vault-password-file /root/.vault_pass

    # 4. Run it (this runs cobbler sync: DHCP starts on the cluster network; c01 stays netboot off)
    ansible-playbook master.yml --tags cobbler --vault-password-file /root/.vault_pass

    # 5. Check
    cobbler profile report --name=AlmaLinux-9-minimal-x86_64 | grep 'Automatic Installation Template'
    cobbler system report --name=c01 | grep -E '^(Netboot Enabled|Interface =====)'
    hpc-node status

    # 6. The reproducibility test: build c02 from nothing
    #    (KVM host: create a blank c02 with MAC 52:54:00:aa:bb:02, e.g. lab/lab-node.sh create 2)
    hpc-node provision c02          # or: hpc-node provision c02 --no-power, then start the VM
    hpc-node log c02                # ends with: c02 READY
