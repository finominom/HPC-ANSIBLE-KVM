# What changed in cobbler_provisioning, and why (each item was a real failure in the lab)

| # | File | Change | Failure it prevents |
|---|------|--------|---------------------|
| 1 | tasks/install_media.yml | `cobbler import` replaced by: loop-mount, rsync tree, `cobbler distro add` with `tree=`, `profile add` | Minimal ISO has a `Minimal` repo, not BaseOS: import cannot match a signature; first run died in Cobbler's rsync |
| 2 | tasks/install_media.yml | distro gets `--autoinstall-meta=tree=<url>` (also repaired on existing distros) | installer received literal `inst.repo=$tree` |
| 3 | tasks/configure_cobbler.yml + defaults | `default_password_crypted` set from `hpc_root_password_hash` (assert it is a real hash) | root password was Cobbler's shipped default, or a placeholder hash that nobody could log in with |
| 4 | files/hpc-provision-lib.sh, hpc-node | `power_restart` = off, wait, on; `bootdev pxe` optional (`hpc_ipmi_set_bootdev`) | `power cycle` is rejected by VirtualBMC; `reset` does not apply a new boot order; VirtualBMC `bootdev pxe` is permanent and drops `hd` |
| 5 | lab/lab-node.sh | VM boot order `network,hd`; `pxe` does off/on | node sat at "Booting from local disk" with no disk entry in its boot order |
| 6 | defaults | `hpc_package_environment` variable; `hpc_master_ip` | unverified `@^minimal-environment`; hard-coded address |
| 7 | tasks/install_controller.yml | writes `/root/.ipmi-mhpc` from `hpc_ipmi_password` | BMC password file was a manual step |
| 9 | tasks/install_pxe.yml (new) | packages, `server`/`next_server_v4`/`manage_*` settings, `mkloaders`, DHCP subnet block, services, firewall | all typed by hand in the master history (lines 781-790) |
| 10 | tasks/register_nodes.yml (new) | `hpc_nodes` list creates/updates Cobbler systems (netboot off until provision) | `cobbler system add` was typed by hand |
| 11 | tasks/install_media.yml | profile is created without `--autoinstall`; configure_cobbler sets it after the template exists | `profile add` fails if the template is not deployed yet |
| 8 | lab/vbmcd.service | systemd unit that clears the stale PID file | vbmcd died and `vbmc` timed out |
| 9 | tasks/network_boot.yml (new) | packages, Cobbler `server`/`next_server_v4`/`manage_dhcp*`/`manage_tftpd`, dhcpd subnet block, services, `mkloaders`, firewall, /etc/hosts | all typed by hand on the master (history 781-790) |
| 10 | tasks/configure_cobbler.yml + `hpc_nodes` | registers nodes (netboot off) | `cobbler system add c01` was typed by hand |
| 11 | templates/hpc-compute.ks.j2 + defaults | `@core` and the `repo --name=Minimal` line, both from the kickstart that worked | role defaulted to unverified `@^minimal-environment` and no repo line |
| 12 | validate template + `hpc_validate_time_sync` | time check optional | isolated lab has no time source, so READY could never be reached |

Tested here: ansible-core syntax check; the dhcp subnet replace on a sample template (changes once, then idempotent); kickstart and validation templates rendered with Ansible.
Not tested: I could only syntax-check the role (ansible-core) and render the kickstart template; I have
not run it against your master. Not covered: the old `cobbler` role (from your first playbook run). It also imports the ISO, so remove
its import step or it will fight `install_media.yml`. Not captured: the second NIC attached to c01 on `mgmt`.

## v2: changes for a reproducible rebuild (KVM inventory)

| # | File | Change | Why |
|---|------|--------|-----|
| 13 | project/master.yml | old `cobbler` role replaced by `cobbler_provisioning` | the two roles switched the profile between two kickstarts on every run |
| 14 | tasks/main.yml | `network_boot.yml` and `register_nodes.yml` removed (merged into `install_pxe.yml` / `configure_cobbler.yml`) | the same work done twice, with two different DHCP regexes |
| 15 | templates/hpc-nodes.yml.j2, defaults | `hpc_nodes` built from the inventory (`cobbler_mac`, `cluster_hosts`, `node_if_cluster`) | the node list was kept in two places |
| 16 | configure_cobbler.yml, provisioning.yml | NIC name per node from `node_if_cluster` (enp1s0), not a hardcoded `eno1` | editing c01 with `--interface=eno1` would add a second interface with the same MAC |
| 17 | defaults | `hpc_inventory` = the inventory master.yml ran with | `inventory/cobbler.ini` does not exist, so `hpc-node-configure` failed |
| 18 | lib.sh, hpc-provision.conf | uses `/root/.vault_pass` if it exists | `hpc-node-configure` runs from systemd and cannot type the vault password |
| 19 | install_media.yml | existing distro reused; ISO + SHA-256 only needed when importing; tree URL read from the distro | the ISO check ran every time, and `tree=` could be overwritten with a URL that returns nothing |
| 20 | install_pxe.yml | installs `cobbler`, `pykickstart`, `syslinux-*`; SELinux booleans; firewall rules in the zone of the cluster NIC; DHCP `routers` and node gateway only when `cluster_pkg_source: nat`; one-subnet check | these came from the old role, which no longer runs |
| 21 | configure_cobbler.yml | profile kickstart edited only when different | it caused a `cobbler sync` on every run |
| 22 | provisioning.yml | disk layout 12 GB / + 2 GB swap | defaults need about 60 GB; the KVM nodes have 20 GB |

Tested here: `ansible-playbook master.yml --syntax-check` against a copy of your KVM inventory;
the node list, kickstart, provision.conf and validate playbook rendered with your values;
the DHCP replace on your real dhcp.template (it restores the block exactly, leaves the `#for`
loop intact and is idempotent, with and without `routers`); distro-report parsing on sample text.
Not tested: running it against your master or Cobbler itself.
